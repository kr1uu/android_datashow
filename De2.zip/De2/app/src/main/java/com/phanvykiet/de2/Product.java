package com.phanvykiet.de2;

public class Product {
    int PhoneCode;
    String PhoneName;
    double Price;

    public Product(int PhoneCode, String PhoneName, double Price) {
        this.PhoneCode = PhoneCode;
        this.PhoneName = PhoneName;
        this.Price = Price;
    }

    public int getPhoneCode() { return PhoneCode; }

    public void setPhoneCode(int phoneCode) {
        this.PhoneCode = PhoneCode;
    }

    public String getPhoneName() {
        return PhoneName;
    }

    public void setPhoneName(String PhoneName) {
        this.PhoneName = PhoneName;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public String getInfo() {
        return "Phone Code: " + PhoneCode + ", Phone Name: " + PhoneName + ", Price: " + Price;
    }
}