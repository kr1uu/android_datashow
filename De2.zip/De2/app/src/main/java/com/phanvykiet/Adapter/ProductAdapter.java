package com.phanvykiet.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.phanvykiet.de2.MainActivity;
import com.phanvykiet.de2.Product;
import com.phanvykiet.de2.R;

import java.util.List;

public class ProductAdapter extends BaseAdapter {
    MainActivity context;
    private int layout;
    private List<Product> productList;
    private LayoutInflater inflater;

    public ProductAdapter(Context context, int layout, List<Product> productList) {
        this.context = (MainActivity) context;
        this.layout = layout;
        this.productList = productList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return productList.size();
    }
    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null){
            holder = new ViewHolder();
            convertView = inflater.inflate(layout, null);

            holder.txtInfo = convertView.findViewById(R.id.txtInfo);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Product p = productList.get(position);
        holder.txtInfo.setText(p.getPhoneName()+" - "+String.format("%.0fd", p.getPrice()));

        return convertView;
    }

    static class ViewHolder {
        TextView txtInfo;
    }
}

