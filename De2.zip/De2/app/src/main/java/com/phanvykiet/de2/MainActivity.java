package com.phanvykiet.de2;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import com.phanvykiet.Adapter.ProductAdapter;
import com.phanvykiet.de2.databinding.ActivityMainBinding;
import java.util.ArrayList;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    ProductAdapter adapter;
    ArrayList<com.phanvykiet.de2.Product> productList;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prepareDb();
        loadData();
    }

    private void loadData() {
        adapter = new ProductAdapter(MainActivity.this, R.layout.layout, getDataFromDb());
        binding.lsvProduct.setAdapter(adapter);
    }

    private List<com.phanvykiet.de2.Product> getDataFromDb() {
        productList = new ArrayList<>();
        Cursor cursor = db.queryData("SELECT * FROM " + Database.TBL_NAME);
        while (cursor.moveToNext()){
            productList.add(new Product(cursor.getInt(0), cursor.getString(1), cursor.getDouble(2)));
        }
        cursor.close();
        return productList;
    }

    private void prepareDb() {
        db = new Database(MainActivity.this);
        db.createSampleData();
    }
}